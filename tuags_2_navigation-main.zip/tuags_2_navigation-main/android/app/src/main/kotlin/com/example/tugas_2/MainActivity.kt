package com.example.tugas_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
